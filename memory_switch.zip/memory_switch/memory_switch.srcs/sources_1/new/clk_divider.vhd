library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity clk_divider is
    port (  clk_in : in std_logic;
            rst : in std_logic;
            clk_out : out std_logic);
end clk_divider;

architecture Behavioral of clk_divider is

signal count : integer := 1;
signal tmp : std_logic :='0';
begin

clk_1hz: process(clk_in) 
    begin
        if(rising_edge(clk_in)) then
            if rst = '1' then
                count <= 1;
                tmp <= '0';
            else
                count <= count + 1; 
                if (count = 25000) then            -- COUNT: 25 for 1 Hz
                    tmp <= not tmp;             -- 25000 for 1 khz
                    count <= 1;
                end if;    
            end if;
        end if;
        clk_out <= tmp;
    end process;

end;