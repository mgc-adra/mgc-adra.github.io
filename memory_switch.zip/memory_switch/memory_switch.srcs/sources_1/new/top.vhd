
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity top is
    Port ( clk  : in STD_LOGIC;
           rst  : in STD_LOGIC;
           addr_in  : in STD_LOGIC_VECTOR (7 downto 0);
           en   : in STD_LOGIC;
           we   : in STD_LOGIC_VECTOR (0 downto 0);
           din  : in STD_LOGIC_VECTOR (7 downto 0);
           dout : out STD_LOGIC_VECTOR (7 downto 0));
end top;

architecture Behavioral of top is

component clk_divider is
    port (  clk_in : in std_logic;
            rst : in std_logic;
            clk_out : out std_logic);
end component;

COMPONENT blk_mem_gen_0
  PORT (
    clka : IN STD_LOGIC;
    ena : IN STD_LOGIC;
    wea : IN STD_LOGIC_VECTOR(0 DOWNTO 0);
    addra : IN STD_LOGIC_VECTOR(7 DOWNTO 0);
    dina : IN STD_LOGIC_VECTOR(7 DOWNTO 0);
    douta : OUT STD_LOGIC_VECTOR(7 DOWNTO 0) 
  );
END COMPONENT;

signal clk_1hz: STD_LOGIC;
signal addr : STD_LOGIC_VECTOR(7 DOWNTO 0);

begin

clock: clk_divider port map (clk_in => clk, rst => rst, clk_out => clk_1hz);

memory: blk_mem_gen_0 port map (clka => clk_1hz,
                                ena => en,
                                wea => we,
                                addra => addr_in,
                                dina => din,
                                douta => dout);
                               
end Behavioral;