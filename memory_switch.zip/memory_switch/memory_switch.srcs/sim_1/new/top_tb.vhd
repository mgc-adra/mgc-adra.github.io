library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity top_tb is
--  Port ( );
end top_tb;

architecture Behavioral of top_tb is

component top is
    Port ( clk  : in STD_LOGIC;
           rst  : in STD_LOGIC;
           addr_in  : in STD_LOGIC_VECTOR (7 downto 0);
           en   : in STD_LOGIC;
           we   : in STD_LOGIC_VECTOR (0 downto 0);
           din  : in STD_LOGIC_VECTOR (7 downto 0);
           dout : out STD_LOGIC_VECTOR (7 downto 0));
end component;

signal clk  : STD_LOGIC;
signal rst  : STD_LOGIC;
signal addr_in  : STD_LOGIC_VECTOR (7 downto 0);
signal en   : STD_LOGIC;
signal we   : STD_LOGIC_VECTOR (0 downto 0);
signal din  : STD_LOGIC_VECTOR (7 downto 0);
signal dout : STD_LOGIC_VECTOR (7 downto 0);

begin

testbench: top port map (   clk => clk,
                            rst => rst,
                            addr_in => addr_in,
                            en => en,
                            we => we,
                            din => din,
                            dout => dout );

clk_process: process
begin
clk <= '1';
wait for 10 ns;
clk <= '0';
wait for 10 ns;
end process;

rst_process: process
begin
rst <= '1';
wait for 5 ms;
rst <= '0';
wait;
end process;

read_enable: process
begin
en <= '0';
wait for 20 ms;
en <= '1';
wait;
end process;

write_enable: process
begin
we <= "0";
wait for 50 ms;
we <= "1";
wait for 50 ms;
end process;

data: process
begin
din <= X"51";
wait for 5 ms;
din <= X"52";
wait for 5 ms;
din <= X"53";
wait for 5 ms;
din <= X"54";
wait for 5 ms;
din <= X"55";
wait for 5 ms;
din <= X"56";
wait for 5 ms;
din <= X"57";
wait for 5 ms;
din <= X"58";
wait for 5 ms;
din <= X"59";
wait for 5 ms;
din <= X"5A";
wait for 5 ms;
din <= X"81";
wait for 5 ms;
din <= X"82";
wait for 5 ms;
din <= X"83";
wait for 5 ms;
din <= X"84";
wait for 5 ms;
din <= X"85";
wait for 5 ms;
din <= X"86";
wait for 5 ms;
din <= X"87";
wait for 5 ms;
din <= X"88";
wait for 5 ms;
din <= X"89";
wait for 5 ms;
din <= X"8A";
wait for 5 ms;
end process;

address: process
begin
addr_in <= X"11";
wait for 5 ms;
addr_in <= X"12";
wait for 5 ms;
addr_in <= X"13";
wait for 5 ms;
addr_in <= X"14";
wait for 5 ms;
addr_in <= X"15";
wait for 5 ms;
addr_in <= X"16";
wait for 5 ms;
addr_in <= X"17";
wait for 5 ms;
addr_in <= X"18";
wait for 5 ms;
addr_in <= X"19";
wait for 5 ms;
addr_in <= X"1A";
wait for 5 ms;
addr_in <= X"2B";
wait for 5 ms;
addr_in <= X"2C";
wait for 5 ms;
addr_in <= X"2D";
wait for 5 ms;
addr_in <= X"2E";
wait for 5 ms;
addr_in <= X"2F";
wait for 5 ms;
addr_in <= X"30";
wait for 5 ms;
addr_in <= X"31";
wait for 5 ms;
addr_in <= X"32";
wait for 5 ms;
addr_in <= X"33";
wait for 5 ms;
addr_in <= X"34";
wait for 5 ms;
end process;

end Behavioral;
