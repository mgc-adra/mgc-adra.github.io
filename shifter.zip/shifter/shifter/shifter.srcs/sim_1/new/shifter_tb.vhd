----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 09/17/2023 12:55:34 PM
-- Design Name: 
-- Module Name: shifter_tb - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity shifter_tb is
--  Port ( );
end shifter_tb;

architecture Behavioral of shifter_tb is
component shifter is
    Port ( a : in STD_LOGIC_VECTOR (7 downto 0);
           y : out STD_LOGIC_VECTOR (7 downto 0);
           amt : in STD_LOGIC_VECTOR (2 downto 0);
           shift_sel : in STD_LOGIC);
end component shifter;

    signal a_tb, y_tb : std_logic_vector (7 downto 0);
    signal amt_tb : std_logic_vector (2 downto 0);
    signal shift_sel_tb : std_logic;

begin
    DUT : shifter port map ( a => a_tb, y => y_tb, amt => amt_tb, shift_sel => shift_sel_tb );
    
    process
    begin
    
        -- left shift 1 bit
        a_tb <= "11111111";
        y_tb <= "11111110";
        amt_tb <= "001";
        shift_sel_tb <= '1';
        wait for 10 ns;
        
        -- left shift 2 bits
        a_tb <= "11111111";
        y_tb <= "11111100";
        amt_tb <= "010";
        shift_sel_tb <= '1';
        wait for 10 ns;
        
        -- left shift 4 bits        
        a_tb <= "11111111";
        y_tb <= "11110000";
        amt_tb <= "100";
        shift_sel_tb <= '1';
        wait for 10 ns;
        
        -- right shift 3 bits
        a_tb <= "11111111";
        y_tb <= "00011111";
        amt_tb <= "011";
        shift_sel_tb <= '0';
        wait for 10 ns;
        
        -- right shift 5 bits
        a_tb <= "11111111";
        y_tb <= "00000111";
        amt_tb <= "101";
        shift_sel_tb <= '0';
        wait for 10 ns;
        
        -- right shift 6 bits
        a_tb <= "11111111";
        y_tb <= "00000011";
        amt_tb <= "110";
        shift_sel_tb <= '0';
        wait for 10 ns;
        
        
        
        
        -- left shift 0 bits
        a_tb <= "10110101";
        y_tb <= "10110101";
        amt_tb <= "000";
        shift_sel_tb <= '1';
        wait for 10 ns;
        
        -- left shift 6 bits
        a_tb <= "10110101";
        y_tb <= "01000000";
        amt_tb <= "110";
        shift_sel_tb <= '1';
        wait for 10 ns;
        
        -- left shift 3 bits
        a_tb <= "10110101";
        y_tb <= "10101000";
        amt_tb <= "011";
        shift_sel_tb <= '1';
        wait for 10 ns;
        
        -- right shift 2 bits
        a_tb <= "10110101";
        y_tb <= "00101101";
        amt_tb <= "010";
        shift_sel_tb <= '0';
        wait for 10 ns;
        
        -- right shift 4 bits
        a_tb <= "10110101";
        y_tb <= "00001011";
        amt_tb <= "100";
        shift_sel_tb <= '0';
        wait for 10 ns;
        
        -- right shift 8 bits
        a_tb <= "10110101";
        y_tb <= "00000000";
        amt_tb <= "111";
        shift_sel_tb <= '0';
        wait for 10 ns;
        
        
    end process;

end Behavioral;








