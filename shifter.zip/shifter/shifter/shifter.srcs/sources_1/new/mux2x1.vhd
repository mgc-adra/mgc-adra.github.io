----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 09/15/2023 10:43:58 AM
-- Design Name: 
-- Module Name: mux2x1 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity mux2x1 is
    Port ( mux_in1 : in std_logic_vector (7 downto 0);
           mux_in0 : in std_logic_vector (7 downto 0);
           sel : in STD_LOGIC;
           mux_out : out std_logic_vector (7 downto 0));
end mux2x1;

architecture Behavioral of mux2x1 is

begin

mux_out <= mux_in1 WHEN sel ='1' ELSE
            mux_in0;

end Behavioral;
