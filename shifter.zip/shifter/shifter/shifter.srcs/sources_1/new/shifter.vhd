----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 09/15/2023 10:29:51 AM
-- Design Name: 
-- Module Name: shifter - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity shifter is
    Port ( a : in STD_LOGIC_VECTOR (7 downto 0);
           y : out STD_LOGIC_VECTOR (7 downto 0);
           amt : in STD_LOGIC_VECTOR (2 downto 0);
           shift_sel : in STD_LOGIC);
end shifter;

architecture Behavioral of shifter is

    component mux2x1 is
        Port ( mux_in1 : in std_logic_vector (7 downto 0);
               mux_in0 : in std_logic_vector (7 downto 0);
               sel : in STD_LOGIC;
               mux_out : out std_logic_vector (7 downto 0));
    end component mux2x1;
    
    signal mux1_in1, mux1_in0, mux1_out : std_logic_vector (7 downto 0);
    signal mux2_in1, mux2_in0, mux2_out : std_logic_vector (7 downto 0);
    signal mux4_in1, mux4_in0, mux4_out : std_logic_vector (7 downto 0);
    signal mux5_in1, mux5_in0, mux5_out : std_logic_vector (7 downto 0);
    signal mux6_in1, mux6_in0, mux6_out : std_logic_vector (7 downto 0);
    signal mux7_in1, mux7_in0, mux7_out : std_logic_vector (7 downto 0);
    signal mux8_in1, mux8_in0 : std_logic_vector(7 downto 0);
    signal rshift_out : std_logic_vector (7 downto 0) ;
    signal lshift_out : std_logic_vector (7 downto 0) ;

begin

    -- RIGHT SHIFT
    mux1_inst: mux2x1 port map (mux_in1 => mux1_in1, mux_in0 => mux1_in0, sel => amt(0), mux_out => mux1_out);
    --shift 1 bit to the right
    mux1_in1 <= '0' & a(7 downto 1);
    mux1_in0 <= a(7 downto 0);
        
    mux2_inst: mux2x1 port map (mux_in1 => mux2_in1, mux_in0 => mux2_in0, sel => amt(1), mux_out => mux2_out);
    --shift 2 bit to the right
    mux2_in1 <= "00" & mux1_out(7 downto 2);
    mux2_in0 <= mux1_out(7 downto 0);
    
    mux4_inst: mux2x1 port map (mux_in1 => mux4_in1, mux_in0 => mux4_in0, sel => amt(2), mux_out => mux4_out);
    --shift 4 bit to the right
    mux4_in1 <= "0000" & mux2_out(7 downto 4);
    mux4_in0 <= mux2_out(7 downto 0);
    
    rshift_out <= mux4_out;
    
    -- LEFT SHIFT
    mux5_inst: mux2x1 port map (mux_in1 => mux5_in1, mux_in0 => mux5_in0, sel => amt(0), mux_out => mux5_out);
    --shift 1 bit to the right
    mux5_in1 <= a(6 downto 0) & '0';
    mux5_in0 <= a(7 downto 0);
        
    mux6_inst: mux2x1 port map (mux_in1 => mux6_in1, mux_in0 => mux6_in0, sel => amt(1), mux_out => mux6_out);
    --shift 2 bit to the right
    mux6_in1 <= mux5_out(5 downto 0) & "00";
    mux6_in0 <= mux5_out(7 downto 0);
    
    mux7_inst: mux2x1 port map (mux_in1 => mux7_in1, mux_in0 => mux7_in0, sel => amt(2), mux_out => mux7_out);
    --shift 4 bit to the right
    mux7_in1 <= mux6_out(3 downto 0) & "0000";
    mux7_in0 <= mux6_out(7 downto 0);
    
    lshift_out <= mux7_out;
    
    mux8_inst: mux2x1 port map(mux_in1 => lshift_out, mux_in0 => rshift_out, sel => shift_sel, mux_out => y);
    
end Behavioral;
