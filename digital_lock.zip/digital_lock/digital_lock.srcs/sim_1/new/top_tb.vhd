----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 11/28/2023 03:34:16 PM
-- Design Name: 
-- Module Name: top_tb - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity top_tb is
--  Port ( );
end top_tb;

architecture Behavioral of top_tb is

component top is
    Port ( clk          : in STD_LOGIC;
           rst          : in STD_LOGIC;
           entry        : in STD_LOGIC;
           password     : in STD_LOGIC_VECTOR (3 downto 0);
           lock         : out STD_LOGIC);
end component;

signal clk_tb          : STD_LOGIC;
signal rst_tb          : STD_LOGIC;
signal entry_tb        : STD_LOGIC;
signal password_tb     : STD_LOGIC_VECTOR (3 downto 0);
signal lock_tb         : STD_LOGIC;

begin

top_tb : top port map (clk        => clk_tb,
                       rst        => rst_tb,
                       entry      => entry_tb,
                       password   => password_tb,
                       lock       => lock_tb);

clk_process : process
begin
clk_tb <= '1';
wait for 10 ns;
clk_tb <= '0';
wait for 10 ns;
end process;

rst_process : process
begin
rst_tb <= '1';
wait for 10 ns;
rst_tb <= '0';
wait;
end process;

process
begin
entry_tb <= '0';
wait for 5 ms;
password_tb <= "0000";
entry_tb <= '1';
wait for 5 ms;
entry_tb <= '0';
wait for 5 ms;
password_tb <= "1010";
entry_tb <= '1';
wait for 5 ms;
entry_tb <= '0';
wait for 5 ms;
password_tb <= "1100";
entry_tb <= '1';
wait for 5 ms;
entry_tb <= '0';
wait for 5 ms;
password_tb <= "0000";
entry_tb <= '1';
wait for 5 ms;
entry_tb <= '0';
wait for 5 ms;
password_tb <= "0001";
entry_tb <= '1';
wait for 5 ms;
entry_tb <= '0';
wait for 5 ms;
password_tb <= "0000";
entry_tb <= '1';
wait for 5 ms;
entry_tb <= '0';
wait for 5 ms;
password_tb <= "1010";
entry_tb <= '1';
wait for 5 ms;
entry_tb <= '0';
wait for 5 ms;
password_tb <= "0001";
entry_tb <= '1';
wait for 5 ms;
entry_tb <= '0';
wait for 5 ms;
password_tb <= "0000";
entry_tb <= '1';
wait for 5 ms;
entry_tb <= '0';
wait for 5 ms;
password_tb <= "1010";
entry_tb <= '1';
wait for 5 ms;
entry_tb <= '0';
wait for 5 ms;
password_tb <= "1100";
entry_tb <= '1';
wait for 5 ms;
end process;

end Behavioral;
