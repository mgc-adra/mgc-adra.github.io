
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity top is
    Port ( clk          : in STD_LOGIC;
           rst          : in STD_LOGIC;
           entry        : in STD_LOGIC;                         -- write_enable
           password     : in STD_LOGIC_VECTOR (3 downto 0);     -- data_in
           lock         : out STD_LOGIC);                       -- data_out
end top;

architecture Behavioral of top is

component clk_divider is
    port (  clk_in : in std_logic;
            rst : in std_logic;
            clk_out : out std_logic);
end component;

component controller is
    Port ( clk : in STD_LOGIC;
           rst : in STD_LOGIC;
           entry : in STD_LOGIC;
           value : in STD_LOGIC_VECTOR (3 downto 0);
           lock : out STD_LOGIC );
end component;

signal clk_1hz : std_logic;

begin

clock : clk_divider port map (clk_in => clk, rst => rst, clk_out => clk_1hz);

code_input : controller port map (  clk => clk_1hz,
                                    rst => rst,
                                    entry => entry,
                                    value => password,
                                    lock => lock);

end Behavioral;
