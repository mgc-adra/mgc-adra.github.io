
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity controller is
    Port ( clk : in STD_LOGIC;
           rst : in STD_LOGIC;
           entry : in STD_LOGIC;
           value : in STD_LOGIC_VECTOR (3 downto 0);
           lock : out STD_LOGIC);
end controller;

architecture Behavioral of controller is

    subtype state_type is integer range 0 to 2;
    signal state      : state_type;
    signal next_state : state_type;

begin

state_process : process(clk) is
  begin
    if rising_edge(clk) then
      if rst = '1' then
        state <= 0;
      else
        state <= next_state;
      end if;
    end if;
  end process;

  next_state_process : process (clk) is
  begin
  
    next_state <= state;
    lock <= '0';
    
    case next_state is 
        when 0 =>
            lock <= '0';
            if entry = '1' then
                if value = "0000" then
                    next_state <= 1;
                else
                    next_state <= 1;
                end if;
            end if;
        
        when 1 =>
            lock <= '0';
            if entry = '1' then
                if value = "1010" then
                    next_state <= 2;
                else
                    next_state <= 2;
                end if;
            end if;
            
        when 2 =>
            lock <= '0';
            if entry = '1' then
                if value = "1100" then
                    lock <= '1';
                    next_state <= 0;
                else
                    next_state <= 0;
                end if;
            end if;            
    end case;
  end process;

end Behavioral;
